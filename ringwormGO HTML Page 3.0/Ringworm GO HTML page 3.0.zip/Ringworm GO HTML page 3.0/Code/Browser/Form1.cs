﻿using CefSharp;
using CefSharp.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RingwormGO__lite_vesrion_Chrominium
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ChromiumWebBrowser chrome;

        public Control Chrome { get; private set; }

        private void button5_Click(object sender, EventArgs e)
        {
            ChromiumWebBrowser chrome = tabControl1.SelectedTab.Controls[0] as ChromiumWebBrowser;
            if (chrome != null)
                chrome.Load("https://www.google.com");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CefSettings settings = new CefSettings();
            //Initialize
            Cef.Initialize(settings);
            textBox1.Text = "https://www.google.com";
            chrome = new ChromiumWebBrowser(textBox1.Text);
            chrome.Parent = tabControl1.SelectedTab;
            chrome.Dock = DockStyle.Fill;
            chrome.AddressChanged += Chrome_AddressChanged;
            chrome.TitleChanged += Chrome_TitleChanged;
        }

        private void Chrome_AddressChanged(object sender, AddressChangedEventArgs e)
        {
            this.Invoke(new MethodInvoker(() =>
              {
                  textBox1.Text = e.Address;
              }));
        }
        internal class RingwormGo_lite_vesrion_Chrominium
        {
            internal DockStyle Dock;
            public RingwormGo_lite_vesrion_Chrominium(DockStyle dock)
            {
                Dock = dock;
            }

            internal Action<object, AddressChangedEventArgs> AddressChanged;

            public RingwormGo_lite_vesrion_Chrominium(Action<object, AddressChangedEventArgs> addressChanged)
            {
                AddressChanged = addressChanged;
            }

            internal TabPage Parent;
            internal Action<object, TitleChangedEventArgs> TitleChanged;

            public RingwormGo_lite_vesrion_Chrominium(string text)
            {
            }

            internal void Load(string text)
            {
                throw new NotImplementedException();
            }

            internal void Refresh()
            {
                throw new NotImplementedException();
            }


        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Door webbrowser by CefSharp";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ChromiumWebBrowser chrome = tabControl1.SelectedTab.Controls[0] as ChromiumWebBrowser;
            if (chrome != null)
                chrome.Load(textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (chrome != null)
                chrome.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChromiumWebBrowser chrome = tabControl1.SelectedTab.Controls[0] as ChromiumWebBrowser;
            if (chrome != null)
            {
                if (chrome.CanGoBack)
                    chrome.Back();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Cef.Shutdown();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ChromiumWebBrowser chrome = tabControl1.SelectedTab.Controls[0] as ChromiumWebBrowser;
            if (chrome != null)

            {
                if (chrome.CanGoForward)
                    chrome.Forward();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            TabPage tab = new TabPage();
            tab.Text = "New tab";
            tabControl1.Controls.Add(tab);
            tabControl1.SelectTab(tabControl1.TabCount - 1);
            ChromiumWebBrowser chrome = new ChromiumWebBrowser("https://www.google.com");
            chrome.Parent = tab;
            chrome.Dock = DockStyle.Fill;
            textBox1.Text = "https://www.google.com";
            chrome.AddressChanged += Chrome_AddressChanged;
            chrome.TitleChanged += Chrome_TitleChanged;
        }

        private void Chrome_TitleChanged(object sender, TitleChangedEventArgs e)
        {
            this.Invoke(new MethodInvoker(() =>
            {
                tabControl1.SelectedTab.Text = e.Title;
            }));
        }

        private void textBox1_KeyDown(object By, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ChromiumWebBrowser chrome = tabControl1.SelectedTab.Controls[0] as ChromiumWebBrowser;
                if (chrome != null)
                    chrome.Load(textBox1.Text);
            }
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            
        }
    }
}