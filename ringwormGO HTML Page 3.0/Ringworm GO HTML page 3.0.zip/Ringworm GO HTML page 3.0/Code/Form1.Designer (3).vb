﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtStatus = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.WaterBoxManualToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitFromSecondFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditWindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MaximizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackgroundColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrangeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnimationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CombineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WaterIceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WaterFireToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WaterWaterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.IceFireToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IceIceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.FireFireToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExplosionWaterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExplosionIceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExplosionFireToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.SpeedSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.ResetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TutorialToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.gboxGame = New System.Windows.Forms.GroupBox()
        Me.gboxIce = New System.Windows.Forms.GroupBox()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.gboxWater = New System.Windows.Forms.GroupBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.gboxFire = New System.Windows.Forms.GroupBox()
        Me.ProgressBar3 = New System.Windows.Forms.ProgressBar()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer6 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer7 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer8 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer9 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer10 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer11 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer12 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer13 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer14 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer15 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer16 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer17 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer18 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer19 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer20 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer21 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer22 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer23 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer24 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer25 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer26 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer27 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer28 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer29 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer30 = New System.Windows.Forms.Timer(Me.components)
        Me.gboxExtraWater = New System.Windows.Forms.GroupBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.MoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DrawToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FireToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.YellowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrangeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.gboxGame.SuspendLayout()
        Me.gboxIce.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboxWater.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboxFire.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboxExtraWater.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.Color.Black
        Me.Button1.ForeColor = System.Drawing.Color.Red
        Me.Button1.Location = New System.Drawing.Point(12, 386)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(107, 52)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "⚙"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(382, 1)
        Me.txtStatus.Multiline = True
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtStatus.Size = New System.Drawing.Size(503, 20)
        Me.txtStatus.TabIndex = 1
        Me.txtStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button7)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Controls.Add(Me.CheckBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(674, 338)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(206, 103)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Settings"
        Me.GroupBox1.Visible = False
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(7, 73)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(114, 23)
        Me.Button7.TabIndex = 2
        Me.Button7.Text = "Hide settings"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(7, 44)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 1
        Me.Button6.Text = "Show all"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(7, 20)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(74, 17)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Heat view"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Silver
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditWindowToolStripMenuItem, Me.AnimationToolStripMenuItem, Me.HelpToolStripMenuItem, Me.MoreToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(897, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.OpenToolStripMenuItem, Me.SaveToolStripMenuItem, Me.ToolStripSeparator2, Me.ExitToolStripMenuItem, Me.ToolStripSeparator3, Me.ExitFromSecondFormToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem1, Me.WaterBoxManualToolStripMenuItem})
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'FileToolStripMenuItem1
        '
        Me.FileToolStripMenuItem1.Name = "FileToolStripMenuItem1"
        Me.FileToolStripMenuItem1.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.FileToolStripMenuItem1.Size = New System.Drawing.Size(245, 22)
        Me.FileToolStripMenuItem1.Text = "File"
        '
        'WaterBoxManualToolStripMenuItem
        '
        Me.WaterBoxManualToolStripMenuItem.Name = "WaterBoxManualToolStripMenuItem"
        Me.WaterBoxManualToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.WaterBoxManualToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.WaterBoxManualToolStripMenuItem.Text = "WaterBox Manual"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(189, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(189, 6)
        '
        'ExitFromSecondFormToolStripMenuItem
        '
        Me.ExitFromSecondFormToolStripMenuItem.Name = "ExitFromSecondFormToolStripMenuItem"
        Me.ExitFromSecondFormToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.ExitFromSecondFormToolStripMenuItem.Text = "Exit from second form"
        '
        'EditWindowToolStripMenuItem
        '
        Me.EditWindowToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MaximizeToolStripMenuItem, Me.BackgroundColorToolStripMenuItem})
        Me.EditWindowToolStripMenuItem.Name = "EditWindowToolStripMenuItem"
        Me.EditWindowToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.EditWindowToolStripMenuItem.Text = "Edit window"
        '
        'MaximizeToolStripMenuItem
        '
        Me.MaximizeToolStripMenuItem.Name = "MaximizeToolStripMenuItem"
        Me.MaximizeToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.MaximizeToolStripMenuItem.Text = "Maximize"
        '
        'BackgroundColorToolStripMenuItem
        '
        Me.BackgroundColorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrangeToolStripMenuItem})
        Me.BackgroundColorToolStripMenuItem.Name = "BackgroundColorToolStripMenuItem"
        Me.BackgroundColorToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.BackgroundColorToolStripMenuItem.Text = "Background color"
        '
        'OrangeToolStripMenuItem
        '
        Me.OrangeToolStripMenuItem.Name = "OrangeToolStripMenuItem"
        Me.OrangeToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.OrangeToolStripMenuItem.Text = "Orange"
        '
        'AnimationToolStripMenuItem
        '
        Me.AnimationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CombineToolStripMenuItem, Me.ToolStripSeparator7, Me.SpeedSettingsToolStripMenuItem, Me.ToolStripSeparator8, Me.ResetToolStripMenuItem})
        Me.AnimationToolStripMenuItem.Name = "AnimationToolStripMenuItem"
        Me.AnimationToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.AnimationToolStripMenuItem.Text = "Animation"
        '
        'CombineToolStripMenuItem
        '
        Me.CombineToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WaterIceToolStripMenuItem, Me.WaterFireToolStripMenuItem, Me.WaterWaterToolStripMenuItem, Me.ToolStripSeparator4, Me.IceFireToolStripMenuItem, Me.IceIceToolStripMenuItem, Me.ToolStripSeparator5, Me.FireFireToolStripMenuItem, Me.ToolStripSeparator6, Me.ExplosionWaterToolStripMenuItem, Me.ExplosionIceToolStripMenuItem, Me.ExplosionFireToolStripMenuItem})
        Me.CombineToolStripMenuItem.Name = "CombineToolStripMenuItem"
        Me.CombineToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CombineToolStripMenuItem.Text = "Combine"
        '
        'WaterIceToolStripMenuItem
        '
        Me.WaterIceToolStripMenuItem.Name = "WaterIceToolStripMenuItem"
        Me.WaterIceToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.WaterIceToolStripMenuItem.Text = "Water + Ice"
        '
        'WaterFireToolStripMenuItem
        '
        Me.WaterFireToolStripMenuItem.Name = "WaterFireToolStripMenuItem"
        Me.WaterFireToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.WaterFireToolStripMenuItem.Text = "Water + Fire"
        '
        'WaterWaterToolStripMenuItem
        '
        Me.WaterWaterToolStripMenuItem.Name = "WaterWaterToolStripMenuItem"
        Me.WaterWaterToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.WaterWaterToolStripMenuItem.Text = "Water + Water"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(177, 6)
        '
        'IceFireToolStripMenuItem
        '
        Me.IceFireToolStripMenuItem.Name = "IceFireToolStripMenuItem"
        Me.IceFireToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.IceFireToolStripMenuItem.Text = "Ice + Fire"
        '
        'IceIceToolStripMenuItem
        '
        Me.IceIceToolStripMenuItem.Name = "IceIceToolStripMenuItem"
        Me.IceIceToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.IceIceToolStripMenuItem.Text = "Ice + Ice"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(177, 6)
        '
        'FireFireToolStripMenuItem
        '
        Me.FireFireToolStripMenuItem.Name = "FireFireToolStripMenuItem"
        Me.FireFireToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.FireFireToolStripMenuItem.Text = "Fire + Fire"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(177, 6)
        '
        'ExplosionWaterToolStripMenuItem
        '
        Me.ExplosionWaterToolStripMenuItem.Name = "ExplosionWaterToolStripMenuItem"
        Me.ExplosionWaterToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExplosionWaterToolStripMenuItem.Text = "Explosion - Water"
        '
        'ExplosionIceToolStripMenuItem
        '
        Me.ExplosionIceToolStripMenuItem.Name = "ExplosionIceToolStripMenuItem"
        Me.ExplosionIceToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExplosionIceToolStripMenuItem.Text = "Explosion - Ice"
        '
        'ExplosionFireToolStripMenuItem
        '
        Me.ExplosionFireToolStripMenuItem.Name = "ExplosionFireToolStripMenuItem"
        Me.ExplosionFireToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExplosionFireToolStripMenuItem.Text = "Explosion - Fire"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(177, 6)
        '
        'SpeedSettingsToolStripMenuItem
        '
        Me.SpeedSettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4, Me.ToolStripMenuItem5, Me.ToolStripMenuItem6, Me.ToolStripMenuItem7, Me.ToolStripMenuItem8, Me.ToolStripMenuItem9, Me.ToolStripMenuItem10, Me.ToolStripMenuItem11, Me.ToolStripSeparator1, Me.ToolStripTextBox1})
        Me.SpeedSettingsToolStripMenuItem.Name = "SpeedSettingsToolStripMenuItem"
        Me.SpeedSettingsToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SpeedSettingsToolStripMenuItem.Text = "Speed settings"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem2.Text = "1"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem3.Text = "2"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem4.Text = "3"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem5.Text = "4"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem6.Text = "5"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem7.Text = "6"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem8.Text = "7"
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem9.Text = "8"
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem10.Text = "9"
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(160, 22)
        Me.ToolStripMenuItem11.Text = "10"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(157, 6)
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Enabled = False
        Me.ToolStripTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(100, 23)
        Me.ToolStripTextBox1.Text = "Start automaticly."
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(177, 6)
        '
        'ResetToolStripMenuItem
        '
        Me.ResetToolStripMenuItem.Name = "ResetToolStripMenuItem"
        Me.ResetToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ResetToolStripMenuItem.Text = "Reset"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TutorialToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'TutorialToolStripMenuItem
        '
        Me.TutorialToolStripMenuItem.Name = "TutorialToolStripMenuItem"
        Me.TutorialToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.TutorialToolStripMenuItem.Text = "Tutorial"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button2.BackColor = System.Drawing.Color.SkyBlue
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(125, 386)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(107, 52)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Water"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(238, 386)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(107, 52)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Ice"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'gboxGame
        '
        Me.gboxGame.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gboxGame.Controls.Add(Me.gboxExtraWater)
        Me.gboxGame.Controls.Add(Me.gboxIce)
        Me.gboxGame.Controls.Add(Me.gboxWater)
        Me.gboxGame.Controls.Add(Me.gboxFire)
        Me.gboxGame.Location = New System.Drawing.Point(12, 27)
        Me.gboxGame.Name = "gboxGame"
        Me.gboxGame.Size = New System.Drawing.Size(873, 305)
        Me.gboxGame.TabIndex = 6
        Me.gboxGame.TabStop = False
        '
        'gboxIce
        '
        Me.gboxIce.Controls.Add(Me.ProgressBar2)
        Me.gboxIce.Controls.Add(Me.PictureBox3)
        Me.gboxIce.Location = New System.Drawing.Point(213, 20)
        Me.gboxIce.Name = "gboxIce"
        Me.gboxIce.Size = New System.Drawing.Size(200, 139)
        Me.gboxIce.TabIndex = 2
        Me.gboxIce.TabStop = False
        Me.gboxIce.Text = "Playing ice..."
        Me.gboxIce.Visible = False
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(7, 98)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(187, 35)
        Me.ProgressBar2.TabIndex = 1
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(6, 20)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(187, 72)
        Me.PictureBox3.TabIndex = 1
        Me.PictureBox3.TabStop = False
        '
        'gboxWater
        '
        Me.gboxWater.Controls.Add(Me.ProgressBar1)
        Me.gboxWater.Controls.Add(Me.PictureBox2)
        Me.gboxWater.Location = New System.Drawing.Point(7, 20)
        Me.gboxWater.Name = "gboxWater"
        Me.gboxWater.Size = New System.Drawing.Size(200, 139)
        Me.gboxWater.TabIndex = 1
        Me.gboxWater.TabStop = False
        Me.gboxWater.Text = "Playing water..."
        Me.gboxWater.Visible = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(6, 98)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(187, 35)
        Me.ProgressBar1.TabIndex = 1
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.InitialImage = CType(resources.GetObject("PictureBox2.InitialImage"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(6, 20)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(187, 72)
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'gboxFire
        '
        Me.gboxFire.Controls.Add(Me.ProgressBar3)
        Me.gboxFire.Controls.Add(Me.PictureBox1)
        Me.gboxFire.Location = New System.Drawing.Point(419, 20)
        Me.gboxFire.Name = "gboxFire"
        Me.gboxFire.Size = New System.Drawing.Size(200, 139)
        Me.gboxFire.TabIndex = 0
        Me.gboxFire.TabStop = False
        Me.gboxFire.Text = "Playing fire..."
        Me.gboxFire.Visible = False
        '
        'ProgressBar3
        '
        Me.ProgressBar3.Location = New System.Drawing.Point(7, 98)
        Me.ProgressBar3.Name = "ProgressBar3"
        Me.ProgressBar3.Size = New System.Drawing.Size(187, 35)
        Me.ProgressBar3.TabIndex = 1
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(7, 20)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(187, 72)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button4.BackColor = System.Drawing.Color.Red
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button4.Location = New System.Drawing.Point(351, 386)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(107, 52)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Fire"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button5.BackColor = System.Drawing.Color.Lime
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button5.Location = New System.Drawing.Point(464, 386)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(107, 52)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Explosion"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        '
        'Timer2
        '
        '
        'Timer3
        '
        '
        'Timer4
        '
        '
        'Timer5
        '
        '
        'Timer6
        '
        '
        'Timer7
        '
        '
        'Timer8
        '
        '
        'Timer9
        '
        '
        'Timer10
        '
        '
        'Timer11
        '
        '
        'Timer12
        '
        '
        'Timer13
        '
        '
        'Timer14
        '
        '
        'Timer15
        '
        '
        'Timer16
        '
        '
        'Timer17
        '
        '
        'Timer18
        '
        '
        'Timer19
        '
        '
        'Timer20
        '
        '
        'Timer21
        '
        '
        'Timer22
        '
        '
        'Timer23
        '
        '
        'Timer24
        '
        '
        'Timer25
        '
        '
        'Timer26
        '
        '
        'Timer27
        '
        '
        'Timer28
        '
        '
        'Timer29
        '
        '
        'Timer30
        '
        '
        'gboxExtraWater
        '
        Me.gboxExtraWater.Controls.Add(Me.PictureBox5)
        Me.gboxExtraWater.Controls.Add(Me.PictureBox4)
        Me.gboxExtraWater.Location = New System.Drawing.Point(120, 195)
        Me.gboxExtraWater.Name = "gboxExtraWater"
        Me.gboxExtraWater.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.gboxExtraWater.Size = New System.Drawing.Size(226, 133)
        Me.gboxExtraWater.TabIndex = 3
        Me.gboxExtraWater.TabStop = False
        Me.gboxExtraWater.Text = "Playing Extra"
        Me.gboxExtraWater.Visible = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Aqua
        Me.PictureBox4.Location = New System.Drawing.Point(6, 19)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(100, 108)
        Me.PictureBox4.TabIndex = 0
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PictureBox5.Location = New System.Drawing.Point(112, 19)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(100, 108)
        Me.PictureBox5.TabIndex = 0
        Me.PictureBox5.TabStop = False
        '
        'MoreToolStripMenuItem
        '
        Me.MoreToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DrawToolStripMenuItem})
        Me.MoreToolStripMenuItem.Name = "MoreToolStripMenuItem"
        Me.MoreToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.MoreToolStripMenuItem.Text = "More"
        '
        'DrawToolStripMenuItem
        '
        Me.DrawToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FireToolStripMenuItem})
        Me.DrawToolStripMenuItem.Name = "DrawToolStripMenuItem"
        Me.DrawToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DrawToolStripMenuItem.Text = "Draw"
        '
        'FireToolStripMenuItem
        '
        Me.FireToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.YellowToolStripMenuItem, Me.OrangeToolStripMenuItem1, Me.RedToolStripMenuItem, Me.RedToolStripMenuItem1})
        Me.FireToolStripMenuItem.Name = "FireToolStripMenuItem"
        Me.FireToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.FireToolStripMenuItem.Text = "Fire"
        '
        'YellowToolStripMenuItem
        '
        Me.YellowToolStripMenuItem.Name = "YellowToolStripMenuItem"
        Me.YellowToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.YellowToolStripMenuItem.Text = "Yellow"
        '
        'OrangeToolStripMenuItem1
        '
        Me.OrangeToolStripMenuItem1.Name = "OrangeToolStripMenuItem1"
        Me.OrangeToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.OrangeToolStripMenuItem1.Text = "Orange"
        '
        'RedToolStripMenuItem
        '
        Me.RedToolStripMenuItem.Name = "RedToolStripMenuItem"
        Me.RedToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.RedToolStripMenuItem.Text = "Dark Red"
        '
        'RedToolStripMenuItem1
        '
        Me.RedToolStripMenuItem1.Name = "RedToolStripMenuItem1"
        Me.RedToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.RedToolStripMenuItem1.Text = "Red"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(897, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.gboxGame)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "WaterBox auto"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.gboxGame.ResumeLayout(False)
        Me.gboxIce.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboxWater.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboxFire.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboxExtraWater.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents txtStatus As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditWindowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FileToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents WaterBoxManualToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents gboxGame As GroupBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents gboxFire As GroupBox
    Friend WithEvents Button4 As Button
    Friend WithEvents gboxIce As GroupBox
    Friend WithEvents gboxWater As GroupBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AnimationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CombineToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ExitFromSecondFormToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button7 As Button
    Friend WithEvents WaterIceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WaterFireToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WaterWaterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents IceFireToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IceIceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents FireFireToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents ExplosionWaterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExplosionIceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExplosionFireToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MaximizeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BackgroundColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrangeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents SpeedSettingsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem9 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As ToolStripMenuItem
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents ProgressBar2 As ProgressBar
    Friend WithEvents ProgressBar3 As ProgressBar
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TutorialToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As ToolStripSeparator
    Friend WithEvents ResetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents Timer4 As Timer
    Friend WithEvents Timer5 As Timer
    Friend WithEvents Timer6 As Timer
    Friend WithEvents Timer7 As Timer
    Friend WithEvents Timer8 As Timer
    Friend WithEvents Timer9 As Timer
    Friend WithEvents Timer10 As Timer
    Friend WithEvents Timer11 As Timer
    Friend WithEvents Timer12 As Timer
    Friend WithEvents Timer13 As Timer
    Friend WithEvents Timer14 As Timer
    Friend WithEvents Timer15 As Timer
    Friend WithEvents Timer16 As Timer
    Friend WithEvents Timer17 As Timer
    Friend WithEvents Timer18 As Timer
    Friend WithEvents Timer19 As Timer
    Friend WithEvents Timer20 As Timer
    Friend WithEvents Timer21 As Timer
    Friend WithEvents Timer22 As Timer
    Friend WithEvents Timer23 As Timer
    Friend WithEvents Timer24 As Timer
    Friend WithEvents Timer25 As Timer
    Friend WithEvents Timer26 As Timer
    Friend WithEvents Timer27 As Timer
    Friend WithEvents Timer28 As Timer
    Friend WithEvents Timer29 As Timer
    Friend WithEvents Timer30 As Timer
    Friend WithEvents gboxExtraWater As GroupBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents MoreToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DrawToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FireToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents YellowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OrangeToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RedToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RedToolStripMenuItem1 As ToolStripMenuItem
End Class